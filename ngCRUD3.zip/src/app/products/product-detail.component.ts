import { Component,
    OnInit,
    OnChanges,
    DoCheck,
    AfterContentInit,
    AfterContentChecked,
    AfterViewInit,
    AfterViewChecked,
    OnDestroy,
    Input,
    SimpleChanges,
    } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';
import { IProducts } from './products';
import { ProductService } from './product.service';

@Component({
    templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent implements OnInit,
OnChanges,
DoCheck,
AfterContentInit,
AfterContentChecked,
AfterViewInit,
AfterViewChecked,
OnDestroy {
    @Input() user: string;
    pageTitle: any = 'Product Detail';
    product: IProducts;
    errorMessage: string;
    private sub: Subscription;

    constructor(private _router: Router,
                private _route: ActivatedRoute,
                private _productService: ProductService) {}

    ngOnChanges(changes: SimpleChanges): void {
        console.log('in ngOnChanges');
    }
    ngOnInit(): void {
        this.sub = this._route.params.subscribe(
            params => {
                const id = +params['id'];
                this.getProduct(id);
            });
            console.log('in Product details ngOnInit');
    }
    ngDoCheck(): void {
        console.log('in ngDoCheck');
    }
    ngAfterContentInit(): void {
        console.log('in ngAfterContentInit');
    }
    ngAfterContentChecked(): void {
        console.log('in ngAfterContentChecked');
    }
    ngAfterViewInit(): void {
        console.log('in ngAfterViewInit');
    }
    ngAfterViewChecked(): void {
        console.log('in ngAfterViewChecked');
    }
    ngOnDestroy(): void {
        this.sub.unsubscribe();
        console.log('in ngOnDestroy');
    }

    getProduct(id: number) {
        this._productService.editProduct(id).subscribe(
            product => {this.product = <IProducts>product[0]; console.log(this.product); } ,
            error => this.errorMessage = <any>error);
    }

    onBack(): void {
        this._router.navigate(['/products']);
    }

    onRatingClicked(message: string): void {
        this.pageTitle = 'Product Detail: ' + message;
    }
}
