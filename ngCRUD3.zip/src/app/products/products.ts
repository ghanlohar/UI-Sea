export interface IProducts {
    productId: Number;
    productName: String;
    productCode: String;
    releaseDate: String;
    description: String;
    category: String;
    price: Number;
    starRating: Number;
    imageUrl: String;
    tags?: string[];
}
