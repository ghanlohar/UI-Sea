import { Component, OnChanges, Input,
          Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'ai-star',
    templateUrl: 'star.component.html',
    styleUrls: ['star.component.css']
})
export class StarComponent implements OnChanges {
    // tslint:disable-next-line:no-input-rename
    @Input('starRating') rating: number;
    starWidth: number;
    private _name: string;
    constructor() {}
    
    @Output() ratingClicked: EventEmitter<string> =
        new EventEmitter<string>();

    ngOnChanges(): void {
        console.log('in ng on changes star');
        this.starWidth = this.rating * 86 / 5;
    }

    get name(): string {
        // transform value for display
        return this._name.toUpperCase();
      }
      
      @Input()
      set name(name: string) {
        console.log('prev value: ', this._name);
        console.log('got name: ', name);
        this._name = name;
      }

    onClick(): void {
        this.ratingClicked.emit(`The rating ${this.rating} was clicked!`);
    }
}
