import { NgModule } from '@angular/core';
import { CreateComponent } from './create/create.component';
import { RouterModule } from '@angular/router';
import { CrudComponent } from './crud.component';
import { IndexComponent } from './index/index.component';
import { EditComponent } from './edit/edit.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: 'crud' ,
                component: CrudComponent,
                children: [
                    {
                        path: 'create',
                        component: CreateComponent
                    },
                    {
                        path: 'edit',
                        component: IndexComponent,
                        children: [
                          {
                            path: ':id',
                            component: EditComponent
                          }
                        ]
                    }
                ]
            }
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class CrudRouteModule {}
