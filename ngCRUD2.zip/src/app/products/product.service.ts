import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { IProducts } from './products';

@Injectable()
export class ProductService {

  constructor(private http: HttpClient) { }

  addProduct(name, price) {
    const uri = 'http://localhost:4000/products/add';
    const obj = {
      name: name,
      price: price
    };
    this.http.post(uri, obj)
        .subscribe(res => console.log('Done'));
  }
  getProducts() {
    const uri = 'http://localhost:4000/products';
    return this
            .http
            .get(uri)
            .map(res => {
              return res;
            });
  }
  editProduct(id) {
    const uri = 'http://localhost:4000/products/edit/' + id;
    return this
            .http
            .get(uri)
            .map(res => {
              return res;
            });
  }

  saveProduct(product: IProducts) {
    const uri = 'http://localhost:4000/products/update/' + product.productId;

    this
      .http
      .post(uri, product).map(res => {
        return res;
      });
  }

  deleteProduct(id) {
    const uri = 'http://localhost:4000/products/delete/' + id;
    return this
            .http
            .delete(uri)
            .map(res => {
              return res;
            });
  }
}
