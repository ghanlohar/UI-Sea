var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Define collection and schema for Items
var Product = new Schema({
  productId: {
    type: Number
  },
  productName: {
    type: String
  },
  productCode: {
    type: String
  },
  releaseDate: {
    type: String
  },
  description: {
    type: String
  },
  category: {
    type: String
  },
  price: {
    type: Number
  },
  starRating: {
    type: Number
  },
  imageUrl: {
    type: String
  },
  tags: {
    type: Array
  }
},{
    collection: 'products'
});

module.exports = mongoose.model('Product', Product);