import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create',
  template: `<nav class="navbar navbar-default">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="active">
        <a [routerLink]="['create']" routerLinkActive="active">
          Add coins
        </a>
      </li>
      <li class="active">
        <a [routerLink]="['edit']" routerLinkActive="active">
          Edit coins
        </a>
      </li>
    </ul>
  </div>
</nav>
<div class="container">
  <router-outlet></router-outlet>
</div>`
})
export class CrudComponent implements OnInit {
  title = 'Acme Product Management';
  constructor() { }

  ngOnInit() {
  }

}
