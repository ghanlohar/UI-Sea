import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './user/auth.service';


@Component({
    selector: 'app-pm',
    template: `
    <div>
        <nav class='navbar navbar-default'>
            <div class='container-fluid'>
                <a class='navbar-brand'>{{pageTitle}}</a>
                <ul class='nav navbar-nav'>
                    <li><a [routerLink]="['/welcome']">Home</a></li>
                    <li><a [routerLink]="['/products']">Product List</a></li>
                    <li><a [routerLink]="['/comms']">Communications</a></li>
                    <li><a [routerLink]="['/crud']">CRUD</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li *ngIf="authService.isLoggedIn()">
                        <a>Welcome {{ authService.currentUser.userName }}</a>
                    </li>
                    <li>
                        <a>Show Messages</a>
                    </li>
                    <li *ngIf="!authService.isLoggedIn()">
                        <a [routerLink]="['/login']">Log In</a>
                    </li>
                    <li *ngIf="authService.isLoggedIn()">
                        <a (click)="logOut()">Log Out</a>
                    </li>
            </ul>
            </div>
        </nav>
        <div class='container'>
            <router-outlet></router-outlet>
        </div>
     </div>
     `,
     styleUrls: ['app.component.css']
})
export class AppComponent {
     pageTitle = 'Acme Product Management';

     constructor(private authService: AuthService,
        private router: Router) { }

    logOut(): void {
        this.authService.logout();
        this.router.navigateByUrl('/welcome');
    }
}
