import { NgModule } from '@angular/core';
import { CreateComponent } from './create/create.component';
import { RouterModule } from '@angular/router';
import { CrudComponent } from './crud.component';
import { IndexComponent } from './index/index.component';
import { EditComponent } from './edit/edit.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            {path: 'crud' , component: CrudComponent},
            {path: 'crud/create' , component: CreateComponent},
            {path: 'crud/edit' , component: IndexComponent},
            {path: 'crud/edit/:id' , component: EditComponent}
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class CrudRouteModule {}
