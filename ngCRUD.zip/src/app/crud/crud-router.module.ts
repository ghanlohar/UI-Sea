import { NgModule } from '@angular/core';
import { CreateComponent } from './create/create.component';
import { RouterModule } from '@angular/router';
import { CrudComponent } from './crud.component';
import { IndexComponent } from './index/index.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            {path: 'crud' , component: CrudComponent},
            {path: 'crud/create' , component: CreateComponent},
            {path: 'crud/edit' , component: IndexComponent}
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class CrudRouteModule {}
