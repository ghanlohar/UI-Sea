import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CrudRouteModule } from './crud-router.module';
import { CrudComponent } from './crud.component';
import { CoinService } from './service/coin.service';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CreateComponent } from './create/create.component';
import { IndexComponent } from './index/index.component';

@NgModule({
  imports: [
    CommonModule,
    CrudRouteModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    CoinService
  ],
  declarations: [
    CrudComponent,
    CreateComponent,
    IndexComponent
  ]
})
export class CrudModule { }
