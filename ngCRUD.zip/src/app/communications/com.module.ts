import { SharedModule } from '../shared/shared.module';
import { NgModule } from '@angular/core';
import { CountdownTimerComponent } from './countdown-timer.component';
import { CountdownLocalVarParentComponent } from './countdown-parent.component';
import { ComRouteModule } from './com-router.module';

@NgModule({
    imports: [
        ComRouteModule,
        SharedModule
    ],
    declarations: [
        CountdownLocalVarParentComponent,
        CountdownTimerComponent
    ],
    providers: []
})
export class ComModule {

}
