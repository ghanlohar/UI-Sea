import { NgModule } from '@angular/core';
import { CountdownLocalVarParentComponent } from './countdown-parent.component';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        RouterModule.forChild([
            {path: 'comms' , component: CountdownLocalVarParentComponent}
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class ComRouteModule {}
